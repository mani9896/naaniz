module.exports={
    API_Key :"193428589218819",
    API_secret: "zvOLaR7eaK4MEoAzLLUKegwbxyA",
    cloud_name: "dhiiwabjw"
}