const socket = io();
const addImage = document.getElementById("compose");
const images = document.querySelector(".fieldS");
socket.on("field", function () {
  var div = document.createElement("div");
  div.classList.add("field");
  div.innerHTML =
    "<label for='dish'>Enter Dish Name</label><input type='text' name='dish' required><label for='qty'>Quantity</label><input type='text' name='qty' required>";
  document.querySelector(".fieldS").appendChild(div);
});
addImage.addEventListener("submit", function (e) {
  e.preventDefault();

  socket.emit("add");
});
