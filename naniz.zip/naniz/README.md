#using npm i express to get started
mini-quora
#use web p image fromat instead of jpg or jpeg format can easily convert it online at https://image.online-convert.com/convert-to-webp
#used css grid to arrange the cards
#used flexbox to design the navigation bar



